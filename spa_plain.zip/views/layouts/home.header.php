<header>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-1">
                <img class="img-responsive" src="resources/assets/logo.png" alt="">
                <div class="text-center">
                    <a href="login" class="btn btn-lg btn-primary standard-button">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</header>