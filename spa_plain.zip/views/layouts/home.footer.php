<footer class="footer">
    <div class="container">
        <p class="colored-white">All Rights Reserved</p>
    </div>
</footer>